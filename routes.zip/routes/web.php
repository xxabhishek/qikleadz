<?php

use App\Http\Controllers\Admin\CityController;
use App\Http\Controllers\Admin\FuelTypeController;
use App\Http\Controllers\Admin\IndustryTypeController;
use App\Http\Controllers\Admin\StateController;
use App\Http\Controllers\Admin\VariantController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\VehicleTypeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();
Route::group(['middleware' => ['auth']], function () {
    Route::resource('roles', 'App\Http\Controllers\Admin\RoleController');
    Route::resource('users', 'App\Http\Controllers\Admin\UserController');
});

//Vehicle type route
Route::resource('vehicle-types', VehicleTypeController::class);
//Industry type route
Route::resource('industry-types', IndustryTypeController::class);
//Fuel Type route
Route::resource('fuel-types', FuelTypeController::class);
//Variant route
Route::resource('variants', VariantController::class);
//Country riute
Route::resource('country', 'App\Http\Controllers\Admin\CountryController');
//model route
Route::resource('model', 'App\Http\Controllers\Admin\ModelController');

//state route
Route::resource('state', StateController::class);
//city route
Route::resource('city', CityController::class);
//Vehicle-Config
Route::resource('vehicle-config','App\Http\Controllers\Admin\VehicleConfigController');
//Color
Route::resource('color','App\Http\Controllers\Admin\ColorController');



Route::get('/get-vehicle-types/{countryId}', [\App\Http\Controllers\Admin\VehicleTypeController::class, 'getByCountry']);
Route::get('/get-industry-types-by-vehicle/{vehicleId}', [\App\Http\Controllers\Admin\IndustryTypeController::class, 'getByVehicle']);

// Route::get('/home', action: [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])
    ->middleware('auth')
    ->name('home');