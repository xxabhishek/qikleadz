<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\VehicleTypeRequest;
use App\Models\Country;
use App\Repositories\VehicleTypeRepository;
use Illuminate\Http\Request;

class VehicleTypeController extends Controller
{
    //

    protected $repository;

    public function __construct(VehicleTypeRepository $repository)
    {
        $this->repository = $repository;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $vehicleTypes = $this->repository->all();
        return view('admin.vehicle-types.index', compact('vehicleTypes'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        $countries = Country::all();
        return view('admin.vehicle-types.create', compact('countries'));
    }

    public function edit($id)
    {
        $vehicleType = $this->repository->find($id);
        $countries = Country::all();
        return view('admin.vehicle-types.edit', compact('vehicleType', 'countries'));
    }

    public function store(VehicleTypeRequest $request)
    {
        $data = $request->only(['name', 'country_id']);
        $this->repository->create($data);

        return redirect()->route('vehicle-types.index')
            ->with('success', 'Vehicle type created successfully');
    }

    public function update(Request $request, $id)
    {
        $data = $request->only(['name', 'country_id']);
        $this->repository->update($id, $data);

        return redirect()->route('vehicle-types.index')
            ->with('success', 'Vehicle type updated successfully');
    }

    public function destroy($id)
    {
        $this->repository->delete($id);
        return redirect()->route('vehicle-types.index')
            ->with('success', 'Vehicle type deleted successfully');
    }
// public function getByIndustry($industryId)
// {
//     return response()->json(\App\Models\VehicleType::where('industry_type_id', $industryId)->get());
// }
}
