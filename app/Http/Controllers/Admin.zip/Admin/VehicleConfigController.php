<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Admin\UpdateVehicleConfigRequest;
use App\Http\Requests\Admin\VehicleConfigRequest;
use App\Models\VehicleConfig;
use App\Services\VehicleConfigService;
Use App\Services\ModelService;
Use App\Services\VariantService;
Use App\Services\FuelTypeService;
Use App\Services\CountryService;
use Illuminate\Contracts\View\Factory;
use Illuminate\Http\Response;
use Illuminate\View\View;
use App\Http\Controllers\Controller;
use File;
use Illuminate\Support\Str;
class VehicleConfigController extends Controller
{
    /** @var VehicleConfigService */
    protected $vehicleConfigService;

    /** @var ModelService */
    protected $modelService;

    /** @var VariantService */
    protected $variantService;

        /** @var FuelTypeService */
    protected $fuelTypeService;

            /** @var CountryService */
    protected $countryService;



    /**
     * CountryController constructor.
     * @param VehicleConfigService $vehicleConfigService
     */
    public function __construct(
        VehicleConfigService $vehicleConfigService ,
        ModelService $modelService,
        VariantService $variantService,
        FuelTypeService $fuelTypeService,
        CountryService $countryService
    ) 
    {
        $this->middleware('auth');
        $this->vehicleConfigService = $vehicleConfigService;
        $this->modelService = $modelService;
        $this->variantService = $variantService;
        $this->fuelTypeService =$fuelTypeService;
        $this->country =$countryService;

    }

    /**
     * @param VehicleConfigDataTable $dataTable
     * @return mixed
     */
    public function index()
    {
        $vehicleConfigs = $this->vehicleConfigService->getAll();
        return view('admin.vehicle-config.index', compact('vehicleConfigs'));
    }

    /**
     * Show the form for creating new Role.
     *
     * @return Response
     */
    public function create()
    {
        // dd('create');
    $vehicleConfigs = $this->vehicleConfigService->getAll();

    return view('admin.vehicle-config.create', compact('vehicleConfigs'));

    }

    /**
     * @param VehicleConfigRequest $request
     * @return mixed
     */
    public function store(VehicleConfigRequest $request)
    {
        // dd($request);
        //$data = $request->all();
        $data = $request->all();
        $result = $this->vehicleConfigService->create($data);
        return redirect()->route('vehicle-config.index')
            ->with('success', 'Vehicle Config created successfully');
    }


    /**
     * @param VehicleConfig $vehicleConfig
     * @return mixed
     */

    public function edit($id)
    {
        $vehicleConfigServices = VehicleConfig::findOrFail($id);
        return view('admin.vehicle-config.edit', compact('vehicleConfigServices'));
    }


    /**
     * @param UpdateVehicleConfigRequest $request
     * @param $id
     * @return mixed
     */
    public function update(UpdateVehicleConfigRequest $request, int $id)
    {
        $data = $request->all();
        $this->vehicleConfigService->update($data, $id);
        return redirect()->route('vehicle-config.index')
            ->with('success', 'VehicleConfig updated successfully');
    }


    public function destroy($id)
    {
        try {
            $this->vehicleConfigService->delete($id);
            return redirect()->route('vehicle-config.index')
                ->with('success', 'Country deleted successfully');
        } catch (\Exception $e) {
            return redirect()->route('vehicle-conig.index')
                ->with('error', $e->getMessage());
        }
    }
}