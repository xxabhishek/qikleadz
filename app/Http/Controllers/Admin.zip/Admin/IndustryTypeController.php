<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\IndustryTypeRequest;
use App\Models\Country;
use App\Repositories\IndustryTypeRepository;
use Illuminate\Http\Request;

class IndustryTypeController extends Controller
{
    //
    protected $repository;

    public function __construct(IndustryTypeRepository $repository)
    {
        $this->repository = $repository;
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $industryTypes = $this->repository->all();
        return view('admin.industry-types.index', compact('industryTypes'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        $countries = Country::all();
        return view('admin.industry-types.create', compact('countries'));
    }

    public function edit($id)
    {
        $industryType = $this->repository->find($id);
        $countries = Country::all();
        return view('admin.industry-types.edit', compact('industryType', 'countries'));
    }

    public function store(IndustryTypeRequest $request)
    {
        $data = $request->only(['name', 'country_id']); // ✅ include country_id
        $this->repository->create($data);

        return redirect()->route('industry-types.index')
            ->with('success', 'Industry type created successfully');
    }

    public function update(IndustryTypeRequest $request, $id)
    {
        $data = $request->only(['name', 'country_id']); // ✅ include country_id
        $this->repository->update($id, $data);

        return redirect()->route('industry-types.index')
            ->with('success', 'Industry type updated successfully');
    }

    public function destroy($id)
    {
        $this->repository->delete($id);
        return redirect()->route('industry-types.index')
            ->with('success', 'Industry type deleted successfully');
    }

// public function getByVehicle($vehicleId)
// {
//     return response()->json(\App\Models\IndustryType::where('vehicle_type_id', $vehicleId)->get());
// }



}