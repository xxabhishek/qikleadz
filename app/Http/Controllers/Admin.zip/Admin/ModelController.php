<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Admin\UpdateModelRequest;
use App\Http\Requests\Admin\ModelRequest;
use App\Models\IndustryType;
use App\Models\VehicleType;
use App\Models\Country;
use App\Services\ModelService;
use App\Http\Controllers\Controller;
use App\Models\ModelDetail;

class ModelController extends Controller
{
    protected $modelService;

    public function __construct(ModelService $modelService)
    {
        $this->middleware('auth');
        $this->modelService = $modelService;
    }

    public function index()
    {
        $models = $this->modelService->getAll();
        return view('admin.model.index', compact('models'));
    }

    public function create()
    {
        $industryTypes = IndustryType::all();
        $vehicleTypes = VehicleType::all();
        $countries = Country::all();

        return view('admin.model.create', compact('industryTypes', 'vehicleTypes', 'countries'));
    }

    public function store(ModelRequest $request)
    {
        $this->modelService->create($request->all());

        return redirect()->route('model.index')
            ->with('success', 'Model created successfully');
    }

    public function edit($id)
    {
        $modelDetail = ModelDetail::findOrFail($id);
        $industryTypes = IndustryType::all();
        $vehicleTypes = VehicleType::all();
        $countries = Country::all();

        return view('admin.model.edit', compact('modelDetail', 'industryTypes', 'vehicleTypes', 'countries'));
    }

    public function update(UpdateModelRequest $request, int $id)
    {
        $this->modelService->update($request->all(), $id);

        return redirect()->route('model.index')
            ->with('success', 'Model updated successfully');
    }

    public function destroy($id)
    {
        try {
            $this->modelService->delete($id);
            return redirect()->route('model.index')
                ->with('success', 'Model deleted successfully');
        } catch (\Exception $e) {
            return redirect()->route('model.index')
                ->with('error', $e->getMessage());
        }
    }
}
