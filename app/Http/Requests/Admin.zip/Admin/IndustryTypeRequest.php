<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class IndustryTypeRequest extends FormRequest
{
    public function authorize()
    {
        return true; // Adjust based on your authorization logic (e.g., admin role)
    }

    public function rules()
    {
        // if editing, get the ID from route
        $id = $this->route('industry_type') ?? null;

        return [
            'name' => 'required|string|max:255|unique:industry_types,name,' . $id,
        ];
    }



    public function messages()
    {
        return [
            'name.required' => 'The industry type name is required.',
            'name.unique' => 'This industry type name is already in use.',
            'name.max' => 'The industry type name must not exceed 255 characters.',
        ];
    }
}
