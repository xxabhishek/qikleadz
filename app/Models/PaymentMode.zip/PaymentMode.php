<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PaymentMode extends Model
{
    use HasFactory;
    protected $fillable = [
        'id',
        'name',
        'country_id'
    ];

    public function country()
    {
        return $this->belongsTo((Country::class));
    }
}